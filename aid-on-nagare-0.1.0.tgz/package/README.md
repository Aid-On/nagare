# @aid-on/nagare (流れ)

**2025年のユニバーサルストリーミング基盤** - `Stream<T>` インターフェースによる統一エコシステム。すべてのAid-Onライブラリが `Stream<T>` を返す設計。

## 🎯 なぜ nagare が必要？

### 🌊 **Stream<T> = ReadableStream + Reactive**
```typescript
// ReadableStream そのものを拡張 (変換不要)
interface Stream<T> extends ReadableStream<T> {
  subscribe(observer: Observer<T>): Subscription;
  collect(): Promise<T[]>;
  take(count: number): Stream<T>;
}

// ゼロコスト抽象化
const stream: Stream<string> = response.body; // ← 実質同じオブジェクト
```

### 🔄 **統一エコシステム**
```typescript
// すべてのライブラリが Stream<T> を返す
unilmp.groq.instant(key).stream("Hello");     // Stream<string>
qwiks.sse(url).events();                      // Stream<Event>  
embersm.memory(id).watch();                   // Stream<MemoryEvent>

// 完璧に合成可能
const combined = merge(
  llmStream,
  eventStream, 
  memoryStream
).pipeThrough(operators.filter(isImportant));
```

### ⚡ **真のエッジネイティブ**
- **Web Streams First**: ReadableStreamが一次実体
- **TransformStream Operators**: ネイティブパフォーマンス
- **Backpressure Native**: Web標準の流量制御
- **AbortSignal**: Web標準キャンセレーション
- **Zero Dependencies**: 純粋Web API

## 📦 インストール

```bash
npm install @aid-on/nagare
```

## 🚀 Basic Usage

### Stream<T> の基本操作

```typescript
import { stream, operators } from "@aid-on/nagare";

// 配列からStream作成
const numbers = stream.array([1, 2, 3, 4, 5]);

// TransformStream オペレーター (ネイティブ性能)
const doubled = numbers
  .pipeThrough(operators.map(x => x * 2))
  .pipeThrough(operators.filter(x => x > 4))
  .pipeThrough(operators.take(2));

// 複数の消費方法
const array = await doubled.collect();           // [6, 8]
const response = doubled.toResponse();           // HTTP Response
const readable = await doubled.toReadableStream(); // ReadableStream<number>

// Reactive subscription (Observable-like)
doubled.subscribe({
  next: value => console.log(value),
  error: err => console.error(err),
  complete: () => console.log("Done")
});

// Native async iteration  
for await (const value of doubled) {
  console.log(value);
}
```

## 🔄 Observable Pattern

### Observer Subscription

```typescript
import { stream } from "@aid-on/nagare";

// RxJS-like subscription
const subscription = stream.array([1, 2, 3, 4, 5])
  .pipeThrough(operators.map(x => x * 2))
  .subscribe({
    next: value => console.log("Next:", value),
    error: error => console.error("Error:", error),
    complete: () => console.log("Stream completed")
  });

// Cleanup
setTimeout(() => {
  subscription.unsubscribe();
  console.log("Unsubscribed:", subscription.closed);
}, 1000);
```

### Function-based Subscription

```typescript
// Simple function subscription
const sub = stream.array([1, 2, 3])
  .subscribe(value => console.log(value));
```

## 🌊 Web Streams Integration

### Edge Function Response

```typescript
// Cloudflare Workers
export default {
  async fetch(request: Request): Promise<Response> {
    return stream.array(["Hello", "World", "Stream"])
      .pipeThrough(operators.map(text => text.toUpperCase()))
      .toResponse({
        headers: { "X-Powered-By": "nagare" }
      });
  }
};
```

### Native Web Streams Compatibility

```typescript
// Response.body is already a ReadableStream
const apiStream = stream.from(response.body)
  .pipeThrough(new TextDecoderStream())
  .pipeThrough(operators.filter(line => line.length > 0))
  .pipeThrough(operators.map(JSON.parse));

// Pipe to WritableStream
await apiStream.pipeTo(new WritableStream({
  write(chunk) {
    console.log("Received:", chunk);
  }
}));
```

## 🎨 TransformStream Operators

### 基本変換

```typescript
import { operators } from "@aid-on/nagare";

// Map - 値変換
stream.array([1, 2, 3])
  .pipeThrough(operators.map(x => x * 2))
  .pipeThrough(operators.map(x => `value: ${x}`));

// Filter - 条件フィルタ
stream.array([1, 2, 3, 4, 5])
  .pipeThrough(operators.filter(x => x % 2 === 0));

// Take - 早期終了
stream.array([1, 2, 3, 4, 5])
  .pipeThrough(operators.take(3)); // [1, 2, 3]
```

### バッチング

```typescript
// Buffer - 指定サイズでバッチ化
stream.array([1, 2, 3, 4, 5])
  .pipeThrough(operators.buffer(2)); // [[1, 2], [3, 4], [5]]
```

## 🏗️ Library Integration Pattern

### How Other Libraries Should Use nagare

```typescript
// @aid-on/unilmp example
export const groq = {
  instant: (apiKey: string) => ({
    stream: (prompt: string): Stream<string> => {
      // Return nagare Stream<T>
      return stream.from(createGroqStream(prompt, apiKey));
    }
  })
};

// @aid-on/qwiks example
export function websocket(url: string) {
  return {
    events: (): Stream<MessageEvent> => {
      return stream.from(createWebSocketStream(url));
    }
  };
}

// Universal composition becomes possible
const aiResponse = unilmp.groq.instant(key).stream("Hello");
const wsEvents = qwiks.websocket(url).events();

// All return Stream<T> - perfect composition
const merged = merge(aiResponse, wsEvents)
  .pipeThrough(operators.map(normalize))
  .pipeThrough(operators.filter(isImportant))
  .toResponse();
```

## 📊 Performance Benefits

### Web Streams Native Performance

| Feature | nagare Stream<T> | RxJS Observable | Custom Stream |
|---------|------------------|-----------------|---------------|
| Bundle Size | ~15KB | ~100KB+ | Variable |
| Edge Compatibility | ✅ Native | ❌ Polyfill | ⚠️ Depends |
| Backpressure | ✅ Built-in | ⚠️ Manual | ⚠️ Manual |
| Memory Efficiency | ✅ Optimal | ⚠️ Buffering | ⚠️ Depends |
| Browser Support | ✅ Native | ✅ Yes | ⚠️ Depends |

### Zero-Cost Abstractions

```typescript
// nagare: ReadableStream IS Stream<T>
const stream = response.body; // No wrapper overhead

// Others: Wrapper objects
const observable = new Observable(observer => {
  // Wrapper overhead + manual backpressure
});
```

## 🎯 Advanced Patterns

### Reactive Data Processing

```typescript
// Real-time data pipeline
const dataStream = stream.from(response.body)
  .pipeThrough(new TextDecoderStream())
  .pipeThrough(operators.map(JSON.parse))
  .pipeThrough(operators.filter(data => data.active))
  .pipeThrough(operators.buffer(10))
  .pipeThrough(operators.map(batch => processBatch(batch)));

// Multiple consumers
dataStream.subscribe(batch => updateUI(batch));
dataStream.subscribe(batch => logAnalytics(batch));
dataStream.subscribe(batch => cacheResults(batch));
```

### Error Handling & Retry

```typescript
// Resilient streaming with retry
const resilientStream = stream.from(unreliableSource)
  .pipeThrough(new TransformStream({
    transform(chunk, controller) {
      try {
        const validated = validateData(chunk);
        controller.enqueue(validated);
      } catch (error) {
        // Skip invalid data or handle retry
        console.warn("Invalid data:", error);
      }
    }
  }));

resilientStream.subscribe({
  next: data => processData(data),
  error: error => {
    console.error("Stream error:", error);
    // Implement retry logic here
  },
  complete: () => console.log("Stream completed")
});
```

## 🛠️ API Reference

### Stream<T> Interface

| Method | Description | Returns |
|--------|-------------|---------|
| `subscribe(observer)` | Subscribe with Observer pattern | `Subscription` |
| `pipeThrough(transform)` | Pipe through TransformStream | `Stream<U>` |
| `toResponse(init?)` | Convert to HTTP Response | `Response` |
| `toReadableStream()` | Get underlying ReadableStream | `Promise<ReadableStream<T>>` |
| `collect()` | Collect all values to array | `Promise<T[]>` |
| `reduce(fn, initial)` | Reduce to single value | `Promise<U>` |
| `take(count)` | Take first N values | `Stream<T>` |
| `takeUntil(predicate)` | Take until condition | `Stream<T>` |

### Operators (TransformStream-based)

| Operator | Description | Type |
|----------|-------------|------|
| `map(fn)` | Transform values | `TransformStream<T, U>` |
| `filter(predicate)` | Filter values | `TransformStream<T, T>` |
| `take(count)` | Take first N | `TransformStream<T, T>` |
| `buffer(size)` | Batch into arrays | `TransformStream<T, T[]>` |

### Factory Functions

| Function | Description | Returns |
|----------|-------------|---------|
| `stream.array(items)` | Create from array | `Stream<T>` |
| `stream.from(readable)` | Create from ReadableStream | `Stream<T>` |
| `stream.empty()` | Create empty stream | `Stream<T>` |
| `stream.of(value)` | Create single-value stream | `Stream<T>` |

## 🏆 Design Principles

### 1. **Web Streams First-Class**
```typescript
// ReadableStream IS Stream<T> (not converted to)
const response = await fetch(url);
const stream = fromReadableStream(response.body); // Zero overhead
```

### 2. **Universal Contract**
```typescript
// All libraries return Stream<T>
function myLibrary(): Stream<Data> {
  return stream.from(createDataStream());
}

// Perfect composition
const result = myLibrary()
  .pipeThrough(operators.map(transform))
  .pipeThrough(operators.filter(validate))
  .toResponse();
```

### 3. **Edge-Optimized**
```typescript
// Memory-aware operations
stream.from(largeDataStream)
  .pipeThrough(operators.buffer(100))  // Process in batches
  .pipeThrough(operators.take(1000))   // Limit total items
  .subscribe(handleBatch);
```

### 4. **Standard-Compatible**
```typescript
// Works with all Web APIs
stream.from(response.body)           // fetch API
  .pipeTo(writable)                  // WritableStream API
  .then(() => console.log("Done"));  // Promise API
```

## 🔗 Ecosystem

Base for all Aid-On streaming libraries:

- **[@aid-on/unilmp](../unilmp)** - LLM streaming → `Stream<string>`
- **[@aid-on/qwiks](../qwiks)** - SSE/WebSocket → `Stream<Event>`
- **[@aid-on/synapser](../synapser)** - Reports → `Stream<Report>`
- **[@aid-on/embersm](../embersm)** - Memory → `Stream<MemoryEvent>`

## 📄 License

MIT

---

**@aid-on/nagare** で2025年のエッジネイティブストリーミングエコシステムを構築しましょう！🌊⚡